# Roblox public Web Play join experiment

This unpacked Brave/Chrome extension applies the two changes that produced playable browser joins to public places `119238997901301` and `189707` on November 1, 2026:

1. It sends `rbx-user-agent: Roblox/Darwin` on that tab's `POST https://gamejoin.roblox.com/v1/join-game` request.
2. If the approved response lacks `joinScript.gameFqdn`, it derives the browser WebTransport hostname from the response's network token, server address, port, and the neighboring WebTransport UDMUX address.

The observed native UDMUX address for two datacenters ended in `.33`; the Web Play address ended in `.34`. A direct browser `WebTransport.ready` probe succeeded for the first public place using this mapping. The extension was installed as an unpacked Brave extension and live tested: **[GUILDS] Build a Dungeon** loaded its playable world, and **Natural Disaster Survival** loaded its multiplayer lobby and world. The extension popup reported `Route supplied (128.116.56.33 → 128.116.56.34)` for the first place. The browser tab was returned to the first place and remained playable. Roblox can change the route format or join behavior.

## Use

1. Open `brave://extensions` or `chrome://extensions`, enable Developer mode, and choose **Load unpacked** with this folder.
2. Open a `https://play.roblox.com/games/start?placeId=...` game page.
3. Click **Public Web Play join**, then **Enable and reload**. The debugger banner indicates that this extension is attached to that tab.
4. When finished, click the extension and choose **Disable and reload**. Navigating the tab away from Web Play also detaches it.

The extension's `debugger` permission can inspect the selected tab's network traffic. The code attaches only after you enable it, intercepts only the game-join POST, and keeps join tickets and tokens in memory. It does not save them to disk or send them to another service. Opening DevTools on the attached tab may detach the extension; enable it again after closing DevTools.

The route mapping is verified for the observed `.33` → `.34` UDMUX pattern and two public experiences. It may fail for other server layouts, browser versions, or Roblox updates. The badge shows `OK` after a hostname is supplied and `ERR` if interception fails. The [research report](../README.md) records the controls and limits.
