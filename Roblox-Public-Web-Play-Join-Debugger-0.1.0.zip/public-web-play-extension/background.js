import { patchJoinResponse } from "./route.mjs";

const JOIN_URL = "https://gamejoin.roblox.com/v1/join-game";
const FETCH_PATTERNS = [
  {
    urlPattern: `${JOIN_URL}*`,
    resourceType: "XHR",
    requestStage: "Request"
  },
  {
    urlPattern: `${JOIN_URL}*`,
    resourceType: "XHR",
    requestStage: "Response"
  }
];

const activeTabs = new Set();
const lastResults = new Map();
const loaded = chrome.storage.session.get("activeTabs").then(async ({ activeTabs: saved = [] }) => {
  for (const tabId of saved) {
    if (!Number.isInteger(tabId)) continue;
    try {
      await chrome.debugger.sendCommand({ tabId }, "Fetch.enable", { patterns: FETCH_PATTERNS });
      activeTabs.add(tabId);
    } catch {
      // An extension reload or browser restart can leave a stale saved tab ID.
    }
  }
  if (saved.length !== activeTabs.size) await persist();
});

function placeIdFromUrl(tabUrl) {
  try {
    const url = new URL(tabUrl);
    const placeId = url.searchParams.get("placeId");
    return url.origin === "https://play.roblox.com" &&
      url.pathname === "/games/start" &&
      /^[1-9]\d*$/.test(placeId || "") &&
      Number.isSafeInteger(Number(placeId));
  } catch {
    return false;
  }
}

function isJoinRequest(params) {
  try {
    const url = new URL(params.request.url);
    return url.origin + url.pathname === JOIN_URL && params.request.method === "POST";
  } catch {
    return false;
  }
}

async function persist() {
  await chrome.storage.session.set({ activeTabs: [...activeTabs] });
}

async function badge(tabId, text, color) {
  try {
    await chrome.action.setBadgeText({ tabId, text });
    if (color) await chrome.action.setBadgeBackgroundColor({ tabId, color });
  } catch {
    // The tab may have closed during a network event.
  }
}

function decodeBody(result) {
  if (!result.base64Encoded) return result.body;
  const binary = atob(result.body);
  return new TextDecoder().decode(Uint8Array.from(binary, (character) => character.charCodeAt(0)));
}

function encodeBody(body) {
  const bytes = new TextEncoder().encode(body);
  let binary = "";
  for (let index = 0; index < bytes.length; index += 8192) {
    binary += String.fromCharCode(...bytes.subarray(index, index + 8192));
  }
  return btoa(binary);
}

async function handlePaused(source, params) {
  const requestId = params.requestId;
  const send = (method, command) => chrome.debugger.sendCommand(source, method, command);
  try {
    if (!isJoinRequest(params)) {
      await send("Fetch.continueRequest", { requestId });
      return;
    }

    if (params.responseStatusCode === undefined) {
      const headers = Object.entries(params.request.headers || {})
        .filter(([name]) => name.toLowerCase() !== "rbx-user-agent")
        .map(([name, value]) => ({ name, value: String(value) }));
      headers.push({ name: "rbx-user-agent", value: "Roblox/Darwin" });
      await send("Fetch.continueRequest", { requestId, headers });
      return;
    }

    const received = await send("Fetch.getResponseBody", { requestId });
    const result = patchJoinResponse(decodeBody(received));
    if (!result.patched) {
      lastResults.set(source.tabId, result.reason);
      await send("Fetch.continueRequest", { requestId });
      return;
    }

    const responseHeaders = (params.responseHeaders || []).filter(
      ({ name }) => !["content-length", "content-encoding", "transfer-encoding"]
        .includes(name.toLowerCase())
    );
    await send("Fetch.fulfillRequest", {
      requestId,
      responseCode: params.responseStatusCode,
      responseHeaders,
      body: encodeBody(result.body)
    });
    lastResults.set(source.tabId, `Route supplied (${result.nativeVip} → ${result.browserVip})`);
    await badge(source.tabId, "OK", "#168a51");
  } catch (error) {
    lastResults.set(source.tabId, `Join patch failed: ${error.message}`);
    await badge(source.tabId, "ERR", "#b62d2d");
    try {
      await send("Fetch.continueRequest", { requestId });
    } catch {
      // Detaching the debugger releases any remaining paused request.
    }
  }
}

chrome.debugger.onEvent.addListener((source, method, params) => {
  void (async () => {
    await loaded;
    if (!activeTabs.has(source.tabId)) return;
    if (method === "Fetch.requestPaused") {
      await handlePaused(source, params);
    } else if (method === "Target.attachedToTarget") {
      const child = { tabId: source.tabId, sessionId: params.sessionId };
      await chrome.debugger.sendCommand(child, "Fetch.enable", { patterns: FETCH_PATTERNS });
    }
  })().catch((error) => {
    lastResults.set(source.tabId, `Interception failed: ${error.message}`);
    void badge(source.tabId, "ERR", "#b62d2d");
  });
});

chrome.debugger.onDetach.addListener((source) => {
  activeTabs.delete(source.tabId);
  lastResults.delete(source.tabId);
  void persist();
  void badge(source.tabId, "");
});

async function enable(tabId) {
  await loaded;
  const tab = await chrome.tabs.get(tabId);
  if (!placeIdFromUrl(tab.url)) throw new Error("Open a Web Play game tab first");
  if (activeTabs.has(tabId)) return;

  await chrome.debugger.attach({ tabId }, "1.3");
  activeTabs.add(tabId);
  try {
    await chrome.debugger.sendCommand({ tabId }, "Fetch.enable", { patterns: FETCH_PATTERNS });
    await chrome.debugger.sendCommand({ tabId }, "Target.setAutoAttach", {
      autoAttach: true,
      waitForDebuggerOnStart: false,
      flatten: true,
      filter: [
        { type: "worker", exclude: false },
        { type: "shared_worker", exclude: false },
        { type: "iframe", exclude: false }
      ]
    });
    await persist();
    await badge(tabId, "ON", "#116db5");
  } catch (error) {
    activeTabs.delete(tabId);
    await persist();
    await chrome.debugger.detach({ tabId }).catch(() => {});
    throw error;
  }
}

async function disable(tabId) {
  await loaded;
  activeTabs.delete(tabId);
  lastResults.delete(tabId);
  await persist();
  await chrome.debugger.detach({ tabId }).catch(() => {});
  await badge(tabId, "");
}

chrome.runtime.onMessage.addListener((message, _sender, reply) => {
  (async () => {
    await loaded;
    const tabId = message?.tabId;
    if (!Number.isInteger(tabId) || tabId < 0) throw new Error("Invalid tab");
    if (message.type === "status") {
      return { enabled: activeTabs.has(tabId), result: lastResults.get(tabId) || "" };
    }
    if (message.type === "enable") {
      await enable(tabId);
      return { enabled: true };
    }
    if (message.type === "disable") {
      await disable(tabId);
      return { enabled: false };
    }
    throw new Error("Unknown action");
  })().then((result) => reply({ ok: true, ...result }), (error) => reply({ ok: false, error: error.message }));
  return true;
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (activeTabs.has(tabId) && changeInfo.url && !placeIdFromUrl(changeInfo.url)) {
    void disable(tabId);
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (activeTabs.has(tabId)) void disable(tabId);
});
