import assert from "node:assert/strict";
import test from "node:test";

test("debugger patches the join request and approved response", async () => {
  const listeners = {};
  const calls = [];
  const original = {
    status: 2,
    joinScript: {
      NetStackTokenValue: "AAECAwQFBgcICQoLDA0ODw==",
      MachineAddress: "10.41.5.30",
      NetStackPort: 50988,
      UdmuxEndpoints: [{ Address: "128.116.56.33" }],
      gameFqdn: null
    }
  };

  globalThis.chrome = {
    storage: { session: {
      get: async () => ({}),
      set: async () => {}
    } },
    action: {
      setBadgeText: async () => {},
      setBadgeBackgroundColor: async () => {}
    },
    debugger: {
      attach: async () => {},
      detach: async () => {},
      sendCommand: async (_source, method, params) => {
        calls.push({ method, params });
        if (method === "Fetch.getResponseBody") {
          return { base64Encoded: false, body: JSON.stringify(original) };
        }
      },
      onEvent: { addListener: (handler) => { listeners.event = handler; } },
      onDetach: { addListener: (handler) => { listeners.detach = handler; } }
    },
    runtime: { onMessage: { addListener: (handler) => { listeners.message = handler; } } },
    tabs: {
      get: async () => ({ url: "https://play.roblox.com/games/start?placeId=119238997901301" }),
      onUpdated: { addListener: () => {} },
      onRemoved: { addListener: () => {} }
    }
  };
  await import("./background.js");

  const response = await new Promise((resolve) => {
    listeners.message({ type: "enable", tabId: 7 }, null, resolve);
  });
  assert.deepEqual(response, { ok: true, enabled: true });
  assert.ok(calls.some(({ method }) => method === "Fetch.enable"));

  const source = { tabId: 7 };
  const request = {
    requestId: "request-1",
    request: {
      url: "https://gamejoin.roblox.com/v1/join-game",
      method: "POST",
      headers: { "rbx-user-agent": "Roblox/Web Mac", Origin: "https://play.roblox.com" }
    }
  };
  listeners.event(source, "Fetch.requestPaused", request);
  await new Promise((resolve) => setImmediate(resolve));
  const continued = calls.find(({ method, params }) =>
    method === "Fetch.continueRequest" && params.requestId === "request-1"
  );
  assert.ok(continued);
  assert.equal(continued.params.headers.find(({ name }) => name === "rbx-user-agent").value, "Roblox/Darwin");
  assert.equal(continued.params.headers.find(({ name }) => name === "Origin").value, "https://play.roblox.com");

  listeners.event(source, "Fetch.requestPaused", {
    ...request,
    responseStatusCode: 200,
    responseHeaders: [
      { name: "Content-Length", value: "1" },
      { name: "Access-Control-Allow-Origin", value: "https://play.roblox.com" }
    ]
  });
  await new Promise((resolve) => setImmediate(resolve));
  const fulfilled = calls.find(({ method, params }) =>
    method === "Fetch.fulfillRequest" && params.requestId === "request-1"
  );
  assert.ok(fulfilled);
  assert.equal(fulfilled.params.responseCode, 200);
  assert.equal(fulfilled.params.responseHeaders.some(({ name }) => name === "Content-Length"), false);
  assert.equal(fulfilled.params.responseHeaders.some(({ name }) => name === "Access-Control-Allow-Origin"), true);
  const patched = JSON.parse(Buffer.from(fulfilled.params.body, "base64").toString("utf8"));
  assert.match(patched.joinScript.gameFqdn, /\.80743822\.qdmux\.roblox\.com$/);
  assert.equal(patched.joinScript.NetStackTokenValue, original.joinScript.NetStackTokenValue);

  delete globalThis.chrome;
});
