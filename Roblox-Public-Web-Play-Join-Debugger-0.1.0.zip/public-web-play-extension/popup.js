"use strict";

const place = document.getElementById("place");
const status = document.getElementById("status");
const toggle = document.getElementById("toggle");
let tabId = null;
let enabled = false;

function placeIdFromUrl(tabUrl) {
  try {
    const url = new URL(tabUrl);
    const placeId = url.searchParams.get("placeId");
    return url.origin === "https://play.roblox.com" &&
      url.pathname === "/games/start" &&
      /^[1-9]\d*$/.test(placeId || "") &&
      Number.isSafeInteger(Number(placeId)) ? placeId : null;
  } catch {
    return null;
  }
}

function render(result = "") {
  status.textContent = result || (enabled ? "Join patch enabled in this tab" : "Join patch disabled");
  toggle.textContent = enabled ? "Disable and reload" : "Enable and reload";
  toggle.disabled = false;
}

async function initialize() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const placeId = placeIdFromUrl(tab?.url);
    if (!placeId || !Number.isInteger(tab?.id)) {
      place.textContent = "Open a play.roblox.com/games/start?placeId=… tab first.";
      status.textContent = "Unavailable in this tab";
      return;
    }
    tabId = tab.id;
    place.textContent = `Place ID: ${placeId}`;
    const response = await chrome.runtime.sendMessage({ type: "status", tabId });
    if (!response?.ok) throw new Error(response?.error || "Could not read status");
    enabled = response.enabled;
    render(response.result);
  } catch (error) {
    status.textContent = error.message;
  }
}

toggle.addEventListener("click", async () => {
  if (tabId === null) return;
  toggle.disabled = true;
  try {
    const response = await chrome.runtime.sendMessage({ type: enabled ? "disable" : "enable", tabId });
    if (!response?.ok) throw new Error(response?.error || "Could not change join patch");
    enabled = response.enabled;
    render();
    await chrome.tabs.reload(tabId);
    window.close();
  } catch (error) {
    status.textContent = error.message;
    toggle.disabled = false;
  }
});

initialize();
